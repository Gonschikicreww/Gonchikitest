# ГОНЩИКИ Website

Enthält:
- index.html
- assets/cars-01.jpeg
- assets/cars-02.jpeg
- assets/tee.svg
- assets/hoodie.svg

Für GitHub Pages: alle Dateien ins Repository laden. `index.html` muss im Hauptverzeichnis liegen.
